import React, { useState, useEffect } from 'react';
import { usePowerUp } from '@/lib/PowerUpContext';

interface CircuitDrawerProps {
  editingPanelIndex: number;
  editingCircuitIndex: number | null;
  onClose: () => void;
}

export default function CircuitDrawer({ editingPanelIndex, editingCircuitIndex, onClose }: CircuitDrawerProps) {
  const { state, dispatch } = usePowerUp();
  const panel = state.panels[editingPanelIndex];
  const editingCircuit = editingCircuitIndex !== null ? panel.circuits[editingCircuitIndex] : null;

  const [circuitId, setCircuitId] = useState(editingCircuit?.id || '');
  const [breaker, setBreaker] = useState(editingCircuit?.breaker || 40);
  const [continuous, setContinuous] = useState(editingCircuit?.continuous || Math.floor((editingCircuit?.breaker || 40) * 0.8));
  // Placeholder for stations
  const [stations, setStations] = useState(editingCircuit?.stations || []);

  useEffect(() => {
    setContinuous(Math.floor(breaker * 0.8));
  }, [breaker]);

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    const newCircuit = {
      id: circuitId,
      breaker,
      continuous,
      stations,
    };
    const updatedPanels = [...state.panels];
    if (editingCircuitIndex === null) {
      // Add new circuit
      updatedPanels[editingPanelIndex] = {
        ...panel,
        circuits: [...panel.circuits, newCircuit],
      };
    } else {
      // Update existing circuit
      const updatedCircuits = [...panel.circuits];
      updatedCircuits[editingCircuitIndex] = newCircuit;
      updatedPanels[editingPanelIndex] = {
        ...panel,
        circuits: updatedCircuits,
      };
    }
    dispatch({ type: 'SET_PANELS', payload: updatedPanels });
    onClose();
  }

  return (
    <div className="fixed bottom-0 left-0 w-full z-50">
      <div className="bg-white rounded-t-2xl shadow-lg p-6 max-w-lg mx-auto">
        <form onSubmit={handleSave} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Circuit ID</label>
            <input
              type="text"
              value={circuitId}
              onChange={e => setCircuitId(e.target.value)}
              required
              className="w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Breaker (A)</label>
            <input
              type="number"
              value={breaker}
              min={1}
              onChange={e => setBreaker(Number(e.target.value))}
              required
              className="w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Continuous (A)</label>
            <input
              type="number"
              value={continuous}
              readOnly
              className="w-full border rounded px-3 py-2 bg-gray-100"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Stations</label>
            {/* StationSelector placeholder */}
            <div className="border rounded px-3 py-2 text-gray-400">StationSelector (coming soon)</div>
          </div>
          <div className="flex gap-2 mt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 rounded bg-gray-200 text-gray-700 hover:bg-gray-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2 rounded bg-blue-600 text-white hover:bg-blue-700"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
} 