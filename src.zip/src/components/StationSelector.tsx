import React, { useState, useMemo } from 'react';
import { usePowerUp } from '@/lib/PowerUpContext';

// Types must match context

type Station = {
  id: string;
  stall?: string;
  images?: string[];
  online?: boolean;
};

type Circuit = {
  id: string;
  breaker: number;
  continuous: number;
  stations: Station[];
};

type Panel = {
  id: string;
  location: string;
  circuits: Circuit[];
};

type Site = {
  id: string;
  name: string;
  address: string;
  panels: Panel[];
};

interface StationSelectorProps {
  currentCircuitId: string;
  onSelect: (station: Station) => void;
}

export default function StationSelector({ currentCircuitId, onSelect }: StationSelectorProps) {
  const { state } = usePowerUp();
  const { site, mode } = state;

  // Gather all stations and their assignments
  const allStations: Station[] = useMemo(() => {
    if (!site || !('panels' in site)) return [];
    return (site as Site).panels.flatMap((panel: Panel) =>
      panel.circuits.flatMap((circuit: Circuit) =>
        circuit.stations.map((station: Station) => ({ ...station }))
      )
    );
  }, [site]);

  // Map stationId -> circuitId
  const stationAssignments: Record<string, string | null> = useMemo(() => {
    const map: Record<string, string | null> = {};
    if (!site || !('panels' in site)) return map;
    (site as Site).panels.forEach((panel: Panel) => {
      panel.circuits.forEach((circuit: Circuit) => {
        circuit.stations.forEach((station: Station) => {
          map[station.id] = circuit.id;
        });
      });
    });
    return map;
  }, [site]);

  // Track which stations are in the current circuit
  const currentCircuitStations = useMemo(() => {
    if (!site || !('panels' in site)) return new Set<string>();
    for (const panel of (site as Site).panels) {
      for (const circuit of panel.circuits) {
        if (circuit.id === currentCircuitId) {
          return new Set(circuit.stations.map((s: Station) => s.id));
        }
      }
    }
    return new Set<string>();
  }, [site, currentCircuitId]);

  // Determine selectable stations
  const selectableStations = useMemo(() => {
    if (mode === 'NEW') {
      // Only unassigned stations
      return allStations.filter(station => !stationAssignments[station.id]);
    }
    // UPDATE: show all
    return allStations;
  }, [allStations, stationAssignments, mode]);

  // Search
  const [query, setQuery] = useState('');
  const filteredStations = useMemo(() => {
    return selectableStations.filter(station =>
      station.id.toLowerCase().includes(query.toLowerCase())
    );
  }, [selectableStations, query]);

  return (
    <div className="w-full">
      <input
        type="text"
        placeholder="Search Station ID..."
        value={query}
        onChange={e => setQuery(e.target.value)}
        className="w-full mb-2 px-3 py-2 border rounded"
      />
      <div className="border rounded divide-y bg-white">
        {filteredStations.length === 0 && (
          <div className="py-4 px-4 text-gray-400 text-center">No stations found</div>
        )}
        {filteredStations.map(station => {
          const assignedCircuit = stationAssignments[station.id];
          const isInCurrent = currentCircuitStations.has(station.id);
          const isUnavailable = !isInCurrent && assignedCircuit && assignedCircuit !== currentCircuitId;
          return (
            <div
              key={station.id}
              className={`flex items-center justify-between py-2 px-4 cursor-pointer hover:bg-gray-100 ${
                isInCurrent ? 'bg-blue-50 font-semibold' : ''
              } ${isUnavailable ? 'opacity-50 pointer-events-none' : ''}`}
              onClick={() => {
                if (!isUnavailable) onSelect(station);
              }}
            >
              <span className="font-mono">{station.id}</span>
              <span className={`ml-2 text-xs px-2 py-1 rounded ${
                isInCurrent
                  ? 'bg-blue-200 text-blue-800'
                  : assignedCircuit
                  ? 'bg-gray-200 text-gray-600'
                  : 'bg-green-100 text-green-700'
              }`}>
                {isInCurrent
                  ? 'In this circuit'
                  : assignedCircuit
                  ? assignedCircuit
                  : 'Unassigned'}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
} 