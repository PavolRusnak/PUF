import React, { createContext, useReducer, useContext, ReactNode, Dispatch } from 'react';

// Types
type Station = {
  id: string;
  stall?: string;
  images?: string[];
  online?: boolean;
};

type Circuit = {
  id: string;
  breaker: number;
  continuous: number;
  stations: Station[];
};

type Panel = {
  id: string;
  location: string;
  circuits: Circuit[];
};

type Site = {
  id: string;
  name: string;
  address: string;
};

type PowerUpState = {
  site: Site | null;
  mode: 'NEW' | 'UPDATE';
  panels: Panel[];
};

// Actions
type PowerUpAction =
  | { type: 'SET_SITE'; payload: Site | null }
  | { type: 'SET_MODE'; payload: 'NEW' | 'UPDATE' }
  | { type: 'SET_PANELS'; payload: Panel[] }
  | { type: 'RESET' };

// Initial State
const initialState: PowerUpState = {
  site: null,
  mode: 'NEW',
  panels: [],
};

// Reducer
function powerUpReducer(state: PowerUpState, action: PowerUpAction): PowerUpState {
  switch (action.type) {
    case 'SET_SITE':
      return { ...state, site: action.payload };
    case 'SET_MODE':
      return { ...state, mode: action.payload };
    case 'SET_PANELS':
      return { ...state, panels: action.payload };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
}

// Context
const PowerUpContext = createContext<
  | {
      state: PowerUpState;
      dispatch: Dispatch<PowerUpAction>;
    }
  | undefined
>(undefined);

// Provider
export const PowerUpProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(powerUpReducer, initialState);
  return (
    <PowerUpContext.Provider value={{ state, dispatch }}>
      {children}
    </PowerUpContext.Provider>
  );
};

// Hook
export function usePowerUp() {
  const context = useContext(PowerUpContext);
  if (!context) {
    throw new Error('usePowerUp must be used within a PowerUpProvider');
  }
  return context;
}

// Reset function
export function resetStore(dispatch?: Dispatch<PowerUpAction>) {
  if (!dispatch) {
    throw new Error('resetStore requires a dispatch function');
  }
  dispatch({ type: 'RESET' });
} 