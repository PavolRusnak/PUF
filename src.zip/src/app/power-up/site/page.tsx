import React, { useState } from 'react';
import { PowerUpProvider, usePowerUp } from '@/lib/PowerUpContext';

function PanelAccordion({ panel, mode }: { panel: any; mode: 'NEW' | 'UPDATE' }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border rounded mb-4 bg-white">
      <button
        type="button"
        className="w-full flex justify-between items-center p-4 text-left font-semibold text-lg hover:bg-blue-50"
        onClick={() => setOpen((o) => !o)}
      >
        <span>
          Panel: {panel.id} <span className="text-sm text-gray-500 ml-2">{panel.location}</span>
        </span>
        <span>{open ? '▲' : '▼'}</span>
      </button>
      {open && (
        <div className="p-4 pt-0">
          {panel.circuits && panel.circuits.length > 0 ? (
            panel.circuits.map((circuit: any) => (
              <div key={circuit.id} className="mb-4 border-b pb-2 last:border-b-0 last:pb-0">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-medium">Circuit: {circuit.id}</span>
                    <span className="ml-4 text-sm text-gray-600">Breaker: {circuit.breaker}A</span>
                    <span className="ml-2 text-sm text-gray-600">Continuous: {circuit.continuous}A</span>
                  </div>
                  {mode === 'UPDATE' && (
                    <button className="ml-2 px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded">
                      Edit Circuit
                    </button>
                  )}
                </div>
                <div className="ml-4 mt-2">
                  {circuit.stations && circuit.stations.length > 0 ? (
                    circuit.stations.map((station: any) => (
                      <div key={station.id} className="flex items-center gap-2 mb-1">
                        <span className={`h-3 w-3 rounded-full ${station.online ? 'bg-green-500' : 'bg-gray-400'}`}></span>
                        <span className="font-mono text-sm">{station.id}</span>
                        {station.stall && <span className="ml-2 text-xs text-gray-500">Stall: {station.stall}</span>}
                      </div>
                    ))
                  ) : (
                    <div className="text-xs text-gray-400">No stations</div>
                  )}
                  {mode === 'UPDATE' && (
                    <button className="mt-2 px-2 py-1 text-xs bg-green-100 text-green-800 rounded">
                      Add Station
                    </button>
                  )}
                </div>
              </div>
            ))
          ) : (
            <div className="text-xs text-gray-400">No circuits</div>
          )}
          {mode === 'UPDATE' && (
            <button className="mt-2 px-3 py-1 text-xs bg-blue-100 text-blue-800 rounded">
              Add Circuit
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function SiteSummary() {
  const { state } = usePowerUp();
  const { site, panels, mode } = state;

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* Sticky Header */}
      <header className="sticky top-0 z-10 bg-blue-600 text-white p-4 shadow">
        <div className="max-w-2xl mx-auto">
          <div className="font-bold text-xl">{site?.name || 'Site'}</div>
          <div className="text-sm">{site?.address || ''}</div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-4">
        {(!panels || panels.length === 0) ? (
          <div className="text-center text-gray-500 my-12 text-lg">
            No panels configured yet. Start by adding one.
          </div>
        ) : (
          panels.map((panel: any) => (
            <PanelAccordion key={panel.id} panel={panel} mode={mode} />
          ))
        )}
        <div className="flex justify-center mt-4">
          <button
            className="px-4 py-2 bg-blue-500 text-white rounded shadow hover:bg-blue-600 disabled:opacity-50"
            disabled={mode === 'NEW'}
          >
            Add Panel
          </button>
        </div>
      </main>

      {/* Fixed Finish Button */}
      <div className="fixed bottom-0 left-0 w-full bg-white border-t p-4 flex justify-center z-20">
        <button className="w-full max-w-2xl bg-indigo-600 text-white py-3 rounded shadow hover:bg-indigo-700">
          Finish Site Setup
        </button>
      </div>
    </div>
  );
}

export default function PowerUpSitePage() {
  return (
    <PowerUpProvider>
      <SiteSummary />
    </PowerUpProvider>
  );
} 