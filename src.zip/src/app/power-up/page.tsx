"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { PowerUpProvider, usePowerUp } from '@/lib/PowerUpContext';
import { apiFetch } from '@/lib/useApi';

function PowerUpForm() {
  const [stationId, setStationId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { dispatch } = usePowerUp();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const site = await apiFetch(`/site?stationId=${stationId}`);
      // Determine mode
      let mode: 'NEW' | 'UPDATE' = 'NEW';
      if (
        site.panels &&
        site.panels.some((panel: any) =>
          panel.circuits && panel.circuits.some((circuit: any) => circuit.stations && circuit.stations.length > 0)
        )
      ) {
        mode = 'UPDATE';
      }
      dispatch({ type: 'SET_SITE', payload: site });
      dispatch({ type: 'SET_MODE', payload: mode });
      dispatch({ type: 'SET_PANELS', payload: site.panels || [] });
      router.push('/power-up/site');
    } catch (err: any) {
      setError(err.message || 'Unknown error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="max-w-sm mx-auto p-4 flex flex-col gap-4 justify-center items-center min-h-screen"
    >
      <label htmlFor="stationId" className="block text-sm font-medium text-gray-700 w-full">
        Station ID
      </label>
      <input
        id="stationId"
        name="stationId"
        type="text"
        required
        value={stationId}
        onChange={e => setStationId(e.target.value)}
        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        placeholder="Enter Station ID"
      />
      {error && <div className="text-red-500 text-sm w-full">{error}</div>}
      <button
        type="submit"
        disabled={loading}
        className="w-full bg-indigo-600 text-white py-2 px-4 rounded hover:bg-indigo-700 disabled:opacity-50"
      >
        {loading ? 'Loading...' : 'Continue'}
      </button>
    </form>
  );
}

export default function PowerUpPage() {
  return (
    <PowerUpProvider>
      <PowerUpForm />
    </PowerUpProvider>
  );
} 